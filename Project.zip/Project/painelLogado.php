<?php
include "protect.php";

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Acolhe Food</title>
  <link rel="stylesheet" href="style.css">
  <link rel="shortcut icon" href="logoacolhe.png" type="image/x-icon">
</head>
<body>

  <header>
    <nav class="nav-bar">
      <div class="logo">
                <h1>Acolhe Food</h1>
            </div>
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="#sobre" class="nav-link">Sobre</a></li>
                    <li class="nav-item"><a href="#dicas" class="nav-link">Dicas</a></li>
                    <li class="nav-item"><a href="#contato" class="nav-link">Contato</a></li>
                    <li class="nav-item"><a href="planos/planos.php" class="nav-link">Planos de Assinatura</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
                </ul>
            </div>
            <div class="login-button">
                <button style="border-radius: 30px"><a href=""><?php echo $_SESSION['nome'];?></a></button>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="menu_white_36dp.svg" alt="menu"></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
                    <li class="nav-item"><a href="#sobre" class="nav-link">Sobre</a></li>
                    <li class="nav-item"><a href="#dicas" class="nav-link">Dicas</a></li>
                    <li class="nav-item"><a href="#contato" class="nav-link">Contato</a></li>
                    <li class="nav-item"><a href="planos/planos.php" class="nav-link">Planos de Assinatura</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link">Sair</a></li>
            </ul>
            <div class="login-button">
                <button style="border-radius: 30px"><a href=""><?php echo $_SESSION['nome'];?></a></button>
            </div>
        </div>
  </header>



  <section id="sobre">
    <h2>Sobre Nós</h2>
    <p>Temos a proposta de transformar a alimentação em uma experiência segura, positiva e adaptada para cada mente e necessidade.</p>
  </section>

  <section id="dicas">
    <h2>Dicas de Nutrição</h2>
    <div class="cards">
      <div class="card">
        <img src="https://via.placeholder.com/280x160.png?text=Frutas+Frescas" alt="Frutas Frescas">
        <h3>Consuma Frutas</h3>
        <p>Frutas frescas são fontes naturais de vitaminas, fibras e antioxidantes.</p>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/280x160.png?text=Hidratação" alt="Hidratação">
        <h3>Hidrate-se</h3>
        <p>A água é essencial para o funcionamento do corpo e para o bem-estar mental.</p>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/280x160.png?text=Refeições+Equilibradas" alt="Refeições Equilibradas">
        <h3>Refeições Balanceadas</h3>
        <p>Combine carboidratos, proteínas e gorduras boas para manter a energia e a concentração.</p>
      </div>
    </div>
  </section>

  <section id="contato">
    <h2>Contato</h2>
    <p>Email: <a href="mailto:contato@acolhefood.com">contato@acolhefood.com</a></p>
  </section>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> Acolhe Food. Todos os direitos reservados.</p>
    <p>V 0.1</p>
    <a href="https://www.instagram.com/acolhefood.cie?igsh=ajdoYzM3dW1sMHF1" target="_blank">
      <img id="simboloInsta" src="simbolo_insta.png" alt="Instagram Acolhe Food">
    </a>
  </footer>
  <script>
    function menuShow(){
    let menuMobile = document.querySelector('.mobile-menu');
    if(menuMobile.classList.contains('open')){
        menuMobile.classList.remove('open');
        document.querySelector('.icon').src = "menu_white_36dp.svg";
    }
    else{
        menuMobile.classList.add('open');
        document.querySelector('.icon').src = "close_white_36dp.svg";
    }
  }
  </script>
</body>
</html>