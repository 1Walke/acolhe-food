<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "acolhe_food";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
    die("Conexão falhou: " . $conn->connect_error);
}

?>

<?php
/*
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "acolhe_food";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) 
{
    die("Conexão falhou: " . $conexao->connect_error);
}
*/
?>