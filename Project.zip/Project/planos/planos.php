<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Planos - Acolhe Food</title>
  <link rel="shortcut icon" href="logoacolhe.png" type="image/x-icon">
  <style>
    /* Estilo geral */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f8f9;
      color: #333;
      text-align: center;
    }

    /* Cabeçalho fixo */
    .topo {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #ffffff;
      padding: 10px 40px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .topo .logo {
      font-size: 20px;
      font-weight: bold;
      color: #1f4e37;
    }

    .topo .menu a {
      margin: 0 12px;
      text-decoration: none;
      color: #1f4e37;
      font-weight: 500;
    }

    .topo .menu a:hover {
      text-decoration: underline;
    }

    .topo .usuario {
      background-color: #1f4e37;
      color: white;
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 14px;
    }

    .nav-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 2rem;
    }
    .nav-list ul {
      display: flex;
      list-style: none;
      gap: 1.5rem;
    }

    .nav-list a {
      text-decoration: none;
      color: #2e6042;
      font-weight: 500;
      transition: color 0.3s ease;
    }

    .nav-list a:hover {
      color: #4caf50;
    }
    /* ======= MENU MOBILE LATERAL ======= */
.mobile-menu {
  position: fixed;
  top: 0;
  left: -250px; /* escondido */
  width: 250px;
  height: 100%;
  background: #2e6042;
  padding-top: 3rem;
  transition: left 0.3s ease;
  z-index: 999;
}

.mobile-menu ul {
  list-style: none;
  padding: 0;
}

.mobile-menu .nav-item {
  margin: 1.5rem 0;
  text-align: left;
  padding-left: 1.5rem;
}

.mobile-menu .nav-link {
  color: white;
  text-decoration: none;
  font-size: 1.2rem;
}

.mobile-menu .login-button {
  padding: 1.5rem;
}

.mobile-menu .login-button button {
  width: 100%;
  background: #4caf50;
  border: none;
  padding: 0.6rem;
  border-radius: 5px;
  font-weight: bold;
  color: white;
}

/* Quando o menu está aberto */
.mobile-menu.open {
  left: 0;
}

/* Botão do menu mobile */
.mobile-menu-icon {
  display: none;
}

.mobile-menu-icon button {
  background: transparent;
  border: none;
  cursor: pointer;
}

.mobile-menu-icon img {
  filter: invert(1); /* ícone branco visível */
  width: 32px;
  height: 32px;
}

    /* Título da página */
    header {
      margin-top: 20px;
    }

    header h1 {
      color: #1f4e37;
      font-size: 28px;
    }

    header p {
      color: #555;
      font-size: 16px;
    }

    /* Seções dos planos */
    section {
      max-width: 300px;
      margin: 20px auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    section h2 {
      color: #1f4e37;
      font-size: 22px;
    }

    section ul {
      list-style: none;
      padding: 0;
    }

    section li {
      font-size: 14px;
      margin: 10px 0;
      color: #555;
    }

    /* Botões */
    .botao {
      display: inline-block;
      padding: 10px 18px;
      margin-top: 10px;
      background-color: #1f4e37;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      transition: background-color 0.3s;
    }

    .botao:hover {
      background-color: #286c4d;
    }

    /* Rodapé */
    footer {
      background-color: #285a41;
      color: white;
      padding: 20px;
      margin-top: 95px;
    }

    footer img {
      width: 28px;
      margin-top: 10px;
    }
    @media (max-width: 768px) {
      .nav-list ul {
        display: none;
      }

      .mobile-menu-icon {
        display: block;
      }

      .cards {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>

  <!-- Cabeçalho fixo -->
  <div class="topo">
    <div class="logo">Acolhe Food</div>
    <nav class="menu">
      <a href="../redirecionamento.php">Voltar</a>
    </nav>
        <div class="mobile-menu">
            <ul>
                    <li class="nav-item"><a href="../index.php" class="nav-link">Voltar</a></li>
            </ul>
        </div>
  </div>

  <!-- Conteúdo da página -->
  <header>
     
  </header>

  <section>
    <h2>Plano Basic R$ 14,99</h2>
    <ul>
      <li><strong>Plano Basic:</strong> Dicas semanais e conteúdos gratuitos.</li>
    </ul>
    <a href="plano-basic.php" class="botao">Conferir</a>
  </section>

  <section>
    <h2>Plano Medium R$ 24,99</h2>
    <ul>
      <li><strong>Plano Medium:</strong> Acesso a conteúdos exclusivos, vídeos e suporte nutricional.</li>
      <li><strong>Todos os outros benefícios do plano Basic.</strong></li>
    </ul>
    <a href="plano-medium.php" class="botao">Conferir</a>
  </section>

  <section>
    <h2>Plano Premium R$ 34,99</h2>
    <ul>
      <li><strong>Plano Premium:</strong> Conteúdos adaptados para toda a família.</li>
      <li><strong>Todos os outros benefícios do plano Medium e Basic.</strong></li>
    </ul>
    <a href="plano-premium.php" class="botao">Conferir</a>
  </section>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> Acolhe Food. Todos os direitos reservados.</p>
    <a href="https://www.instagram.com/acolhefood.cie?igsh=ajdoYzM3dW1sMHF1" target="_blank">
      <img id="simboloInsta" src="simbolo_insta.png" alt="Instagram Acolhe Food">
    </a>
  </footer>
</body>
</html>

