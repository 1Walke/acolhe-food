<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Plano Premium - Acolhe Food</title>
  <link rel="shortcut icon" href="logoacolhe.png" type="image/x-icon">
<style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
    }

    body {
      background-color: #f9f9f9;
      color: #333;
      line-height: 1.6;
    }

    header {
      background-color: white;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .nav-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 40px;
    }

    .logo h1 {
      font-size: 1.5rem;
      font-weight: bold;
      color: #2f6d4f;
    }

    .nav-list ul {
      list-style: none;
    }

    .nav-link {
      text-decoration: none;
      color: #2f6d4f;
      font-weight: 600;
      transition: color 0.3s;
    }

    .nav-link:hover {
      color: #1e4a35;
    }

    /* Container principal */
    .container {
      max-width: 1000px;
      margin: 50px auto;
      text-align: center;
      padding: 0 15px;
    }

    .container h2 {
      font-size: 2rem;
      margin-bottom: 25px;
      color: #2f6d4f;
    }

    /* Card do plano */
    .card {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      max-width: 350px;
      margin: 0 auto;
      text-align: center;
    }

    .card h3 {
      font-size: 1.6rem;
      color: #2f6d4f;
      margin-bottom: 10px;
    }

    .card p {
      font-size: 0.95rem;
      color: #555;
      margin-bottom: 20px;
    }

    .card ul {
      padding-left: 0;
      list-style: none;
      margin-bottom: 20px;
    }

    .card li {
      text-align: left;
      padding-left: 25px;
      position: relative;
      margin-bottom: 10px;
      color: #444;
    }

    .card li::before {
      content: "✔";
      color: #7b4fff;
      font-weight: bold;
      position: absolute;
      left: 0;
    }

    .botao {
      background-color: #2f6d4f;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s ease;
    }

    .botao:hover {
      background-color: #265940;
    }

    /* Sessão de dúvidas */
    #duvidas {
      margin-top: 60px;
    }

    #duvidas p {
      margin-bottom: 15px;
      font-size: 0.95rem;
    }

    #duvidas strong {
      color: #2f6d4f;
    }

    /* Rodapé */
    footer {
      background-color: #2f6d4f;
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 100px;
    }

    footer img {
      width: 30px;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <header>
    <nav class="nav-bar">
      <div class="logo">
        <h1>Acolhe Food</h1>
      </div>
      <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="planos.php" class="nav-link">Voltar</a></li>
                </ul>
      </div>
    </nav>
  </header>

  <section class="container" id="plano-s">
    <h2>Plano Premium</h2>
    <div class="card">
      <h3>R$34,99/mês</h3>
      <p>Ideal para quem está começando uma alimentação mais consciente.</p>
      <ul style="text-align: left; margin: 15px 0;">
        <li>✔️ Acesso a receitas semanais</li>
        <li>✔️ Suporte via email</li>
        <li>✔️ Artigos exclusivos</li>
      </ul>
      <form action="comprar.php" method="POST">
        <input type="hidden" name="plano" value="premium">
        <button class="botao" type="submit">Assinar Agora</button>
      </form>
    </div>
  </section>

  <section class="container" id="duvidas">
    <h2>Dúvidas Frequentes</h2>
    <p><strong>Posso cancelar quando quiser?</strong><br>Sim! O cancelamento é simples e pode ser feito a qualquer momento.</p>
    <p><strong>Quais as formas de pagamento?</strong><br>Pix</p>
  </section>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> Acolhe Food. Todos os direitos reservados.</p>
    <a href="https://www.instagram.com/acolhefood.cie?igsh=ajdoYzM3dW1sMHF1" target="_blank">
      <img id="simboloInsta" src="simbolo_insta.png" alt="Instagram Acolhe Food">
    </a>
  </footer>

</body>
</html>