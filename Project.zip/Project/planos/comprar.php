<?php
if (!isset($_SESSION)) {
    session_start();
}

$plano = $_POST['plano'] ?? 'indefinido';
echo "<h1> {$_SESSION['nome']} Você escolheu o plano: " . htmlspecialchars($plano) . "</h1>";
?>